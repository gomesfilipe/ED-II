#include "partial_sorting.h"

struct array {
    int* v;
    int size;    //max quantity
    int length;  //atual quantity
};

Array* create_array(int size) {
    Array* array = (Array*) malloc(sizeof(Array));
    // array->v = (int*) calloc (size, sizeof(int));
    array->v = (int*) malloc (sizeof(int) * size);
    array->size = size;
    array->length = 0;
    return array;
}

void free_array(Array* array) {
    free(array->v);
    free(array);
}

void print_array(Array* array) {
    for(int i = 0; i < array->size; i++) {
        printf("%02d ", array->v[i]);
    }
    printf("\n\n");
}

int* get_array(Array* array) {
    return array->v;
}

int get_size(Array* array) {
    return array->size;
}

int get_length(Array* array) {
    return array->length;
}

int is_full(Array* array) {
    return array->length == array->size;
}

void insert_element_array(Array* array, int element) {
    if(is_full(array)) {
        return;
    }
    array->v[array->length] = element;
    array->length++;
}

void fill_array(Array* array) {
    srand(time(NULL));

    for(int i = 0; i < array->size; i++) {
        insert_element_array(array, rand() % 100);
    }
}

void swap(int* a, int* b) {
    int aux;
    aux = *a;
    *a = *b;
    *b = aux;
}

void partial_selection_sort(Array* array , int k) {
    if(k > array->length) return;
    
    int min = 0;
    // int trocas = 0;
    for(int i = 0; i < k ; i++){
        min = i;
        for(int j = i + 1 ; j < array->size ; j++) {
            if(array->v[j] < array->v[min]) 
                min = j;   
        }
        swap(&array->v[i], &array->v[min]);
        // trocas++;
    }
    // printf("%d trocas\n", trocas);   
}

void partial_insertion_sort(Array* array, int k) {
    if(k > array->length) return;
    
    int inserted, j;
    for(int i = 1; i < array->size; i++){
        inserted = array->v[i];
        
        if(i > k - 1) {
            if(array->v[i] < array->v[k - 1]) {
                swap(&array->v[i], &array->v[k - 1]);
                j = k - 2;
            
            } else {
                continue;
            }
        } else {
            j = i - 1;
        }
        
        for(j; j >= 0; j--){
            if(inserted >= array->v[j])
                break;
            
            array->v[j + 1] = array->v[j];
        }

        array->v[j + 1] = inserted;
    }
}

void partial_shell_sort(Array* array, int k) {
    if(k > array->length) return;
    //int qtd=0;
    int gap;
    for(gap = 1; gap < array->size; gap = 3 * gap + 1); //Calculando gap
    gap = (gap - 1) / 3; //ajustando gap

    int inserted, j;
    for(gap; gap > 0; gap = (gap - 1) / 3){
        for(int i = gap; i < array->size; i++){
            //if(qtd >= k-1) break;
            
            inserted = array->v[i];  

            for(j = i - gap; j >= 0 ; j -= gap){
                if(inserted >= array->v[j])
                    break;
                
                array->v[j + gap] = array->v[j];
                //qtd++;
            }

            array->v[j + gap] = inserted;
        }
    }
}//qtd <= k-1

static void partition(int* array, int begin, int end, int k){
    if(begin >= end) return;
    
    int pivo = begin;
    int j = begin + 1;

    for(int i = begin; i <= end; i++){
        if(array[i] < array[pivo]){
            swap(&array[j], &array[i]);
            j++;
        }
    }

    swap(&array[pivo], &array[j - 1]);
    
    pivo = j - 1;

    partition(array, begin, pivo - 1, k);
    if(pivo - begin < k){
        partition(array, pivo + 1, end, k);    
    }
}

void partial_quick_sort(Array* array, int k) {
    if(k > array->length) return;
}

void partial_heap_sort(Array* array, int k) {
    if(k > array->length) return;
}

//Alogoritmo q pegamos no site
// Function to swap the the position of two elements
  void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
  }
  
  void heapify(int arr[], int n, int i) {
    // Find largest among root, left child and right child
    int largest = i;  //i eh a posiçao do pai
    int left = 2 * i + 1;
    int right = 2 * i + 2;
  
    if (left < n && arr[left] > arr[largest])
      largest = left;
  
    if (right < n && arr[right] > arr[largest])
      largest = right;
  
    // Swap and continue heapifying if root is not largest
    if (largest != i) {
      swap(&arr[i], &arr[largest]);
      heapify(arr, n, largest);
    }
  }
  
  // Main function to do heap sort
  void heapSort(int arr[], int n) {
    // Build max heap
    for (int i = n / 2 - 1; i >= 0; i--) //para começar do ultimo nó com folhas
      heapify(arr, n, i);
  
    // Heap sort  --> o maior elemento ta em v[0]
    for (int i = n - 1; i >= 0; i--) {
      swap(&arr[0], &arr[i]);  //jogando o maior elemebto para a ultima posicao
  
      // Heapify root element to get highest element at root again
      heapify(arr, i, 0);  //chama heapfy dnv so q ja sabe q o ultimo elem é o maior e por isso, chama 
      //heapyfy sem esse maior elem
    }
  }
  
//   // Print an array
//   void printArray(int arr[], int n) {
//     for (int i = 0; i < n; ++i)
//       printf("%d ", arr[i]);
//     printf("\n");
//   }
  
//   // Driver code
//   int main() {
//     int arr[] = {1, 12, 9, 5, 6, 10};
//     int n = sizeof(arr) / sizeof(arr[0]);
  
//     heapSort(arr, n);
  
//     printf("Sorted array is \n");
//     printArray(arr, n);
//   }